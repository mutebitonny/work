#include <stdio.h>
int main(){
    float a,b,sum;
    scanf("%f", &a);
    scanf("%f", &b);
    sum = a + b;
    
    printf("a + b = %.2f\n", sum);

    return 0;


}