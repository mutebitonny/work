#include<stdio.h>
int main(){
    int a,b,sum;
    
    printf("Enter 1st number: ",a);
    scanf("%d",&a);
    printf("Enter 2nd number: ",b);
    scanf("%d",&b);

    sum = a + b;
    printf("Answer >  %d", sum);
    return 0;

}