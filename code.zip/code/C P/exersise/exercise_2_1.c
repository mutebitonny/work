#include <stdio.h>
int main(){
    printf("University of Moratuwa\n");
    printf("Katubedda,\n");
    printf("Moratuwa,\n");
    printf("Sri Lanaka");
    printf("\n--------------------------");
    printf("\nwww.mrt.ac.ik");
    return 0;
}