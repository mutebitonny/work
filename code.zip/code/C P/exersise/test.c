#include<stdio.h>
int main(){
    printf("man");
    return 0;
    
}