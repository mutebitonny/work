#include<stdio.h>
int main(){
    int marks;
    printf("\nEnter the marks: ");
    scanf("%d", &marks);

    if(marks > 50)
    {
        printf("You have passed the exam");
    }
        

    // if(marks < 40){
       
       else
        printf("you have failed the exam!!!!");
    // }
            
    

        return 0;
    }
