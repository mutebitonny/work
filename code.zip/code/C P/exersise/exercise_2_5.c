/* This program prints a number rounded off to the nearest integer 
and also to 2 decimal places*/
#include <stdio.h>
int main(){
    float number  = 34.5678;
    printf("%.0f\n", number);
    printf("%.2f\n", number);
    return 0;



}