#include<stdio.h>
int sum(int x, int y){
    int a;
     a = x + y;
    return(a);

}

int  main(){
    printf("%d", sum(90,100));
    return 0;

}