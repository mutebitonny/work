   #include<stdio.h>
   int main(){
    int num[2][3]= {
        {60,20,10},{100,40,50}
    };
    printf("%d", num);                                                                                                                                              
   }