#include<stdio.h>
int main()
{
    int marks[3];
    marks[0] = 80;
    marks[1] = 90;
    marks[2] = 100;

    printf("%d\n", marks[0]);
    printf("%d\n", marks[1]);
    printf("%d\n", marks[2]);
    return 0;

}