#include<stdio.h>
int main()
{
    int marks[3];

    printf("Enter the first value : ");
    scanf("%d", marks[0]);

     printf("Enter the second value : ");
    scanf("%d", marks[2]);

     printf("Enter the third value : ");
    scanf("%d", marks[2]);
  
    return 0;

}