#include<stdio.h>
int main(){
    int a,x;
    a = 3;
    x = a++;
    printf("a++ = %d\n", a++);
    printf("x = %d\n", x);

    return 0;

}