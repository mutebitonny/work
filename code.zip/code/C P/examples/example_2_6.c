#include<stdio.h>
int main(){
    printf("%d\n", 128);
    printf("%f\n", 128.0);

}