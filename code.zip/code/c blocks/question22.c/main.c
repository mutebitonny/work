#include <stdio.h>
#include <stdlib.h>


void main()
{

    int t;
    float T;
    printf("Enter the time elapsed(seconds):\n");
    scanf("%d",&t);
    T=((float)(4*t*t)/(t+2))-20;
    printf("the temperature is %f\n:",T);


    return 0;
}
