#include <stdio.h>
#include <stdlib.h>

int main()
{

      int one, two;
    printf("Enter the first number\n");
    scanf("%d", &one);
    printf("Enter the second number");
    scanf("%d", &two);
    scanf("%d",&two);
    int sum= one + two;
    printf("The sum is: %d\n", sum);
    int multiply = one * two;
    printf("The product is: %d\n", multiply);
    int difference = one - two;
    printf("The difference is: %d\n", difference);
    float quotient = one/two;
    printf("The quotient is: %d\n", quotient);


    return 0;
}
