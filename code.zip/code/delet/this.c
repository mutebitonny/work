#include<stdio.h>
int main(){
    printf("hello my bro");
    return 0;
}
