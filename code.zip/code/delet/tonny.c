#include<stdio.h>
int main(){
    printf("hello boss\n");
    printf(" Truly you need to check this");
    return 0;
}
