/*
 * interruptonesecond.c
 *
 * Created: 11/23/2022 12:47:17 PM
 * Author : toshiba
 */ 
#define F_CPU 1000000u1
#include <avr/io.h>


int main(void)
{
	int count =0;
	DDRD =0xFF;
	
	sei();
	TCCR0 |=(1<<CS00);// timer 0 start without pascaling
	TCNT0= 0x0;// start 0 
	
	
	   /* Replace with your application code */
    while (1) 
    {
		while ((TIFR&01)>0); //polling
		
    }
}

ISR(TIMER1_COMPC_vect){
	count++;
	if (count == 3921){
		//take action
		PORTD ^=(1<<1);//toggle
		count=0;
	}
	TIFR &=!(1<TOV0);//reset the overflow flag to 0
}
