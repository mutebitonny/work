/*
 * interrupt5.cpp
 *
 * Created: 12/7/2022 2:55:54 PM
 * Author : Mutebi Tonny
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

int main(void)
{
	
	DDRA |= 1<< PINA0;
	DDRA |= 1<<PINA2;
	
	DDRA & = ~(1<<PINA1);
	
	PORTA |= 1<<PINA1;
	
	int i =0, j=0, k=0;
    /* Replace with your application code */
    while (1) 
    {
		if (bit_is_clear(PINA, 1))
		{
			PORTA ^=1 << PINA0;
			_delay_ms(500);
		}
		else{
			PORTA &= ~(1 << PINA0);
			_delay_ms(1000);
			
    }
}

