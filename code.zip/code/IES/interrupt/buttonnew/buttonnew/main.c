/*
 * buttonnew.c
 *
 * Created: 11/23/2022 11:41:31 AM
 * Author : toshiba
 */ 
#include<avr/interrupt.h>
#include <avr/io.h>


int main(void)
{
	DDRD = 0x00; // cause Port D is input
	DDRE = 0xFF; //cause port E is an input wc is 1111111
	EIMSK |=(1<<INT3);
	
	 sei();
    /* Replace with your application code */
    while (1) 
    {
    }
}



ISR(INT3_vect){
	//to do
	//^ means we are toggling  means that incase it is one,, then it will become a zero and vice verser
	PORTE ^= (1<<0);
}
