/*
 * interrupt4.cpp
 *
 * Created: 12/7/2022 2:11:29 PM
 * Author : Mutebi Tonny
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>



int main(void)
{
	sei();
DDRD = 0x00;
DDRE = 0xFF;
EIMSK |= (1<<1);
EICRA |= (1<<3);



    /* Replace with your application code */
    while (1) 
    {
    }
}
ISR(INT1_vect){
PORTE ^= (1<<0);
//cli();
}

