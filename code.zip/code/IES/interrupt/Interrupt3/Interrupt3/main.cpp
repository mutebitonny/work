/*
 * Interrupt3.cpp
 *
 * Created: 12/6/2022 11:43:18 PM
 * Author : Mutebi Tonny
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>



int main(void)
{
    sei();
	DDRD = 0X00;
	DDRE = 0XFF;
	EIMSK |= (1<<1);
	EICRA |= (1<<3);
	//OCR1A = 15524; 
    while (1) 
    {
    }
}

/*ISR(TIMER1_COMPA_vect){
	
	PORTE ^= 1 << PINE1;*/

ISR(INT1_vect){
	//what happens: Light the LED
	PORTE ^= (1<<0);
	
	
	
	
}

