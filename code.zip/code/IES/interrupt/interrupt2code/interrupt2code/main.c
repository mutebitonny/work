/*
 * interrupt2code.c
 *
 * Created: 11/29/2022 9:27:59 AM
 * Author : toshiba
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>


int main(void)
{
	DDRD = 0x00;
	DDRE = 0xFF;// LED
	sei();
	EIMSK |= (1<<1); //Enable int1 interupts.
	//MCUCR |= (1<<2); //Any logical change to the pin
	EICRA |= (1<<3);
	
    /* Replace with your application code */
    while (1) 
    {
    }
}

ISR(INT1_vect){
	//what happens: Light the LED
	PORTE ^= (1<<0);
	
}

