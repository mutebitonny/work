/*
 * button.c
 *
 * Created: 11/23/2022 11:09:58 AM
 * Author : toshiba
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

