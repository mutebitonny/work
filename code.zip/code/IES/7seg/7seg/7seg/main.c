/*
 * 7seg.c
 *
 * Created: 11/23/2022 5:04:58 PM
 * Author : toshiba
 */ 

#include <avr/io.h>


int main(void)
{  
	DDRF = 0xff;
	DDRH =0xff;
    /* Replace with your application code */
    while (1) 
    {
		PORTF = 0x12;
		PORTH = 0xA9;
    }
}

