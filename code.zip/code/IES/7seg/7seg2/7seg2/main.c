/*
 * 7seg2.c
 *
 * Created: 12/18/2022 1:29:45 AM
 * Author : Mutebi Tonny
 */ 

#include <avr/io.h>


int main(void)
{
	DDRF = 0xff;
	DDRH = 0xff;
	
    /* Replace with your application code */
    while (1) 
    {
		//PORTF = 0x00;// this line of code prints out an eight.common anode
		
		PORTF = 0x12;// this line of code prints out a five.common anode
		PORTH = 0x6d;// this prints also  a five but common cathode.
    }
}

