#include<stdio.h>
int main(void){
    int z;
    for(z = 20; z <= 100; z = z + 20)
    {
        if(z == 80)

        continue;

        printf("%d\n", z);
        
    }
    
    return  0;


}
