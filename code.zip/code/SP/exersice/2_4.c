/*Prints the message "Nothing!"
Written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/24/2022

*/


#include<stdio.h>
int main (void){

       //Statements
       printf("This program prints\n\n\t\"Nothing!\"");
       
    return 0;
    
    //main

}