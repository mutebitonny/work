/*This program demonstrates binary expressions.
Written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/24/2022


*/

#include<stdio.h>
int main (void){

    //local Declarations
    int a = 17;
    int b = 5;
    float x = 17.67;
    float y = 5.1;

     //Statements
     printf("Integral calculations\n");
     printf("%d + %d = %d\n", a, b, a + b );
     printf("%d - %d = %d\n", a, b, a - b );
     printf("%d * %d = %d\n", a, b, a * b );
     printf("%d / %d = %d\n", a, b, a / b );
     printf("%d %% %d = %d\n", a, b, a % b );
     printf("\n");

      printf("%f + %f = %f\n", x, y, x - y );
      printf("%f * %f = %f\n", x, y, x * y );
      printf("%f / %f = %f\n", x, y, x / y );

      
    return 0;
    
    //main
     


}