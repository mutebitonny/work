/* The greeting program. This program demonstrates some of the components of a simple C program.
Written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/24/2022
*/

#include<stdio.h>
int main (void){

    //local definiions


     //Statements

     printf("Hello World\n");

     return 0;

     //main
}
