/* This program demonstrates the result of relationaloperators.
 Written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/26/2022
*/
#include<stdio.h>
int main(void){
//Fuction Declarations
int a = 5;
int b = -3;
// Statements
printf("%2d < %2d is %2d\n", a, b, a < b);
printf("%2d == %2d is %2d\n", a, b, a == b);
printf("%2d != %2d is %2d\n", a, b, a != b);
printf("%2d > %2d is %2d\n", a, b, a > b);
printf("%2d <= %2d is %2d\n", a, b, a <= b);
printf("%2d >= %2d is %2d\n", a, b, a >= b);
return 0;
//main
}