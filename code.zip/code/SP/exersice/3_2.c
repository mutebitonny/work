/*
Example of prefix increment.
Written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/24/2022

*/

#include<stdio.h>
int main (void){
      //local Declarations
      int a;

      //Statements
      a = 4;
      printf(" value of a: %2d\n", a);
      printf(" value of a++: %2d\n", ++a);
      printf(" new value of a: %2d\n", a);


    return 0;
    
    //main

}

