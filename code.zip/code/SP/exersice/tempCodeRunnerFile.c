
void getData (int * a, int * b){