/* This program reads two inytergers from the keyborad and prints their product,
written by : Mutebi Tonny 19/U/9055/EVE
Date: 11/24/2022
*/
#include<stdio.h>
int main (void){

  //local Declarations
  int number1; 
   int number2; 
   int result;

   //Statements
   scanf("%d", &number1);
   scanf("%d", &number2);
   result = number1 * number2;
   printf("%d", result);
   return 0;
   // main



}