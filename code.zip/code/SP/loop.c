#include<stdio.h>
int main(){
    int y = 5;
    while(y <50);
    y= y + 10;
    printf("%d", y);
    return 0;
    
}