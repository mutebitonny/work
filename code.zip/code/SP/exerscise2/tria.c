/* this progra prints numbers in an isosceles triangular shape
*/

#include<stdio.h>
int main(){
    int row, i,j,k,l, space_num, num_count;
    printf("Enter the number of row: ");
    scanf("%d", &row);
    space_num = row - 1;

    for(i=0;i<5;i++)
    {

        for(j=0;j<space_num;j++)
        {
                printf("  ");
        }

        space_num--;
        num_count = i+1; 
        for(k=0;k<=i;k++){
            printf("%d ", num_count);
            num_count++;
        }

        for(l=num_count-2;l>=i+1;l--){
            printf("%d ", l);
        }
        printf("\n");
    }
     printf("\n");

     return 0; 
}