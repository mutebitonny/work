/*

This is a calculator programme that can Add, subtract, divide and multiply any two numbers. 
The program starts by choosing  the operation, and then receives two numbers*/
#include<stdio.h>
int main(){
    int num1;
    int num2;
    int choice;

    printf ("\nAdd -1\n");
    printf ("\nSubtract -2\n");
    printf ("\nMultiply -3\n");
    printf ("\nDivide -4\n");
    printf ("\nEnter your choice : \n");
    scanf("%d", &choice);

    printf("Enter number1 :  ");
    scanf("%d", &num1);
    printf("Enter number2 :  ");
    scanf("%d", &num2);
  





switch (choice)
{
case 1: add(num1, num2);

    break;

    case 2: sub(num1, num2);

    break;

    case 3: mult(num1, num2);

    break;

    case 4: divide(num1, num2);

    break;

default:printf("Invalid input!\n");
    break;
    }

}

void add(int a, int b){
    printf("\nResult : %d", a + b);
}

void sub(int a, int b){
    printf("\nResult : %d", a - b);

}


void mult(int a, int b){
    printf("\nResult : %d", a * b);
}


void divide(int a, int b){
    if(b == 0){
        printf("\n You cant divide with zero,, you will get an error");
    }
    else 
   {

     printf("\nResult : %f", a /(float) b);
   }
}








